The following are image pairs used for problem 1 and 2:

book1.JPG,book2.JPG 
coffeeCan1.JPG,coffeeCan2.JPG
squirtle1.JPG,squirtle2.JPG


The following .mat files store their respective points used for image correspondences in Problem 2:

bookPts.mat
coffeeCanPts.mat
squirtlePts.mat


sfm_CalibrationResults contains the calibration data and results
after running the calibration toolbox on the checkerboard images
in the sfm folder


prob1script.m is the whole script for problem 1
prob2script.m is the whole script for problem 2
prob3script.m is the whole script for problem 3

The function getAmatrix.m is used in some of the problem scripts

The SIFT toolbox needs to be installed for the scripts to properly run. 
For the problem 3 script, the sfm folder needs to be in the same place as it for that script to run properly.